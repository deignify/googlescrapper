"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { History, Search, Trash2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { ScrollArea } from "@/components/ui/scroll-area"

interface SearchHistoryProps {
  onSelectQuery: (query: string) => void
}

interface SearchHistoryItem {
  query: string
  timestamp: number
  resultCount: number
}

export function SearchHistory({ onSelectQuery }: SearchHistoryProps) {
  const { toast } = useToast()
  const [history, setHistory] = useState<SearchHistoryItem[]>([])

  // Load search history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("gmb_search_history")
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory))
      } catch (error) {
        console.error("Error loading search history:", error)
      }
    }
  }, [])

  // Remove a history item
  const removeHistoryItem = (query: string) => {
    const updatedHistory = history.filter((item) => item.query !== query)
    setHistory(updatedHistory)
    localStorage.setItem("gmb_search_history", JSON.stringify(updatedHistory))

    toast({
      title: "Search removed",
      description: "Search query has been removed from history",
    })
  }

  // Clear all history
  const clearAllHistory = () => {
    setHistory([])
    localStorage.removeItem("gmb_search_history")

    toast({
      title: "History cleared",
      description: "Search history has been cleared",
    })
  }

  // Format date
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">
          <History className="h-5 w-5 inline mr-2" />
          Search History
        </CardTitle>
        {history.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllHistory}>
            Clear All
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <History className="h-12 w-12 mx-auto mb-3 opacity-20" />
            <p>No search history yet</p>
            <p className="text-sm mt-1">Your search queries will appear here</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-2">
              {history.map((item) => (
                <div key={item.query} className="border rounded-lg p-3 relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7"
                    onClick={(e) => {
                      e.stopPropagation()
                      removeHistoryItem(item.query)
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>

                  <div className="font-medium mb-1 pr-6">{item.query}</div>

                  <div className="flex justify-between items-center text-xs text-muted-foreground">
                    <div>{formatDate(item.timestamp)}</div>
                    <div>{item.resultCount} results</div>
                  </div>

                  <div className="flex gap-2 mt-2">
                    <Button variant="outline" size="sm" className="w-full" onClick={() => onSelectQuery(item.query)}>
                      <Search className="h-3.5 w-3.5 mr-1" />
                      Search Again
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}
