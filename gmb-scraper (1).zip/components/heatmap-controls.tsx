"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Flame } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface HeatmapControlsProps {
  onToggleHeatmap: (enabled: boolean) => void
  onUpdateHeatmapOptions: (options: any) => void
  enabled: boolean
}

export function HeatmapControls({ onToggleHeatmap, onUpdateHeatmapOptions, enabled }: HeatmapControlsProps) {
  const [radius, setRadius] = useState(20)
  const [opacity, setOpacity] = useState(0.7)
  const [intensity, setIntensity] = useState(0.6)
  const [weightProperty, setWeightProperty] = useState("default")

  const handleRadiusChange = (value: number[]) => {
    const newRadius = value[0]
    setRadius(newRadius)
    updateOptions({ radius: newRadius })
  }

  const handleOpacityChange = (value: number[]) => {
    const newOpacity = value[0]
    setOpacity(newOpacity)
    updateOptions({ opacity: newOpacity })
  }

  const handleIntensityChange = (value: number[]) => {
    const newIntensity = value[0]
    setIntensity(newIntensity)
    updateOptions({ intensity: newIntensity })
  }

  const handleWeightPropertyChange = (value: string) => {
    setWeightProperty(value)
    updateOptions({ weightProperty: value })
  }

  const updateOptions = (options: any) => {
    onUpdateHeatmapOptions({
      radius,
      opacity,
      intensity,
      weightProperty,
      ...options,
    })
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium flex items-center">
            <Flame className="h-5 w-5 mr-2" />
            Heatmap Visualization
          </CardTitle>
          <Switch checked={enabled} onCheckedChange={onToggleHeatmap} id="heatmap-toggle" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="radius-slider">Radius</Label>
              <span className="text-sm text-muted-foreground">{radius}px</span>
            </div>
            <Slider
              id="radius-slider"
              min={10}
              max={50}
              step={1}
              value={[radius]}
              onValueChange={handleRadiusChange}
              disabled={!enabled}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="opacity-slider">Opacity</Label>
              <span className="text-sm text-muted-foreground">{Math.round(opacity * 100)}%</span>
            </div>
            <Slider
              id="opacity-slider"
              min={0.1}
              max={1}
              step={0.05}
              value={[opacity]}
              onValueChange={handleOpacityChange}
              disabled={!enabled}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="intensity-slider">Intensity</Label>
              <span className="text-sm text-muted-foreground">{Math.round(intensity * 100)}%</span>
            </div>
            <Slider
              id="intensity-slider"
              min={0.1}
              max={1}
              step={0.05}
              value={[intensity]}
              onValueChange={handleIntensityChange}
              disabled={!enabled}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="weight-property">Weight By</Label>
            <Select value={weightProperty} onValueChange={handleWeightPropertyChange} disabled={!enabled}>
              <SelectTrigger id="weight-property">
                <SelectValue placeholder="Select property" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default (Equal)</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
                <SelectItem value="reviews">Review Count</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="pt-2">
            <p className="text-sm text-muted-foreground">
              Heatmap shows the density of businesses. Adjust settings to visualize different patterns.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
