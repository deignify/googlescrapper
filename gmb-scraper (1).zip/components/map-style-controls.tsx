"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Palette } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import type { MapStyleName } from "@/utils/map-styles"

interface MapStyleControlsProps {
  currentStyle: MapStyleName
  onStyleChange: (style: MapStyleName) => void
}

export function MapStyleControls({ currentStyle, onStyleChange }: MapStyleControlsProps) {
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Map Style
        </CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup value={currentStyle} onValueChange={(value) => onStyleChange(value as MapStyleName)}>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="standard" id="style-standard" />
              <Label htmlFor="style-standard" className="cursor-pointer">
                Standard
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="silver" id="style-silver" />
              <Label htmlFor="style-silver" className="cursor-pointer">
                Silver
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="retro" id="style-retro" />
              <Label htmlFor="style-retro" className="cursor-pointer">
                Retro
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="dark" id="style-dark" />
              <Label htmlFor="style-dark" className="cursor-pointer">
                Dark
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="aubergine" id="style-aubergine" />
              <Label htmlFor="style-aubergine" className="cursor-pointer">
                Aubergine
              </Label>
            </div>
          </div>
        </RadioGroup>

        <div className="mt-4 rounded-md overflow-hidden border h-24 bg-gray-100">
          <div
            className="w-full h-full bg-cover bg-center"
            style={{
              backgroundImage: `url(/placeholder.svg?height=200&width=400&query=map%20style%20${currentStyle})`,
            }}
          />
        </div>
      </CardContent>
    </Card>
  )
}
