"use client"

import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

export function LogoutButton() {
  const { logout } = useAuth()

  return (
    <Button variant="outline" size="sm" onClick={logout} className="gap-1">
      <LogOut className="h-4 w-4" />
      Logout
    </Button>
  )
}
