"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bookmark, Star, MapPin, Phone, Globe, Trash2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Business {
  place_id: string
  name: string
  formatted_address?: string
  vicinity?: string
  formatted_phone_number?: string
  website?: string
  rating?: number
  user_ratings_total?: number
  business_status?: string
  types?: string[]
}

interface BookmarkedBusinessesProps {
  onSelectBusiness: (business: Business) => void
}

export function BookmarkedBusinesses({ onSelectBusiness }: BookmarkedBusinessesProps) {
  const { toast } = useToast()
  const [bookmarks, setBookmarks] = useState<Business[]>([])

  // Load bookmarks from localStorage on component mount
  useEffect(() => {
    const savedBookmarks = localStorage.getItem("gmb_bookmarks")
    if (savedBookmarks) {
      try {
        setBookmarks(JSON.parse(savedBookmarks))
      } catch (error) {
        console.error("Error loading bookmarks:", error)
      }
    }
  }, [])

  // Remove a bookmark
  const removeBookmark = (placeId: string) => {
    const updatedBookmarks = bookmarks.filter((bookmark) => bookmark.place_id !== placeId)
    setBookmarks(updatedBookmarks)
    localStorage.setItem("gmb_bookmarks", JSON.stringify(updatedBookmarks))

    toast({
      title: "Bookmark removed",
      description: "Business has been removed from your bookmarks",
    })
  }

  // Clear all bookmarks
  const clearAllBookmarks = () => {
    setBookmarks([])
    localStorage.removeItem("gmb_bookmarks")

    toast({
      title: "Bookmarks cleared",
      description: "All bookmarks have been removed",
    })
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">
          <Bookmark className="h-5 w-5 inline mr-2" />
          Saved Businesses
        </CardTitle>
        {bookmarks.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllBookmarks}>
            Clear All
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {bookmarks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bookmark className="h-12 w-12 mx-auto mb-3 opacity-20" />
            <p>No bookmarked businesses yet</p>
            <p className="text-sm mt-1">Save businesses to access them quickly later</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {bookmarks.map((business) => (
                <div key={business.place_id} className="border rounded-lg p-3 relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7"
                    onClick={() => removeBookmark(business.place_id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>

                  <h3 className="font-medium mb-1 pr-6">{business.name}</h3>

                  {business.rating && (
                    <div className="flex items-center gap-1 mb-1">
                      <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{business.rating.toFixed(1)}</span>
                      <span className="text-xs text-muted-foreground">({business.user_ratings_total || 0})</span>
                    </div>
                  )}

                  <div className="flex items-start gap-1 text-sm mb-1">
                    <MapPin className="h-3.5 w-3.5 shrink-0 mt-0.5 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {business.formatted_address || business.vicinity || "N/A"}
                    </span>
                  </div>

                  {business.formatted_phone_number && (
                    <div className="flex items-center gap-1 text-sm mb-1">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="text-muted-foreground">{business.formatted_phone_number}</span>
                    </div>
                  )}

                  {business.website && (
                    <div className="flex items-center gap-1 text-sm mb-1">
                      <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                      <a
                        href={business.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline truncate max-w-[200px]"
                      >
                        {business.website.replace(/^https?:\/\/(www\.)?/, "")}
                      </a>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-1 mt-2">
                    {business.types?.slice(0, 3).map((type, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {type.replace(/_/g, " ")}
                      </Badge>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                    onClick={() => onSelectBusiness(business)}
                  >
                    View Details
                  </Button>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}
