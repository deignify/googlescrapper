/**
 * Simple MarkerClusterer implementation for Google Maps
 * This is a simplified version of the MarkerClusterer library
 */
;(() => {
  window.MarkerClusterer = function (map, markers, options) {
    this.map = map
    this.markers = markers || []
    this.clusters = []
    this.ready = false

    this.options = options || {}
    this.gridSize = this.options.gridSize || 60
    this.minClusterSize = this.options.minClusterSize || 2
    this.maxZoom = this.options.maxZoom || 15
    this.imagePath =
      this.options.imagePath || "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m"
    this.imageExtension = this.options.imageExtension || "png"

    this.init()
  }

  MarkerClusterer.prototype.init = function () {
    

    if (this.ready) {
      return
    }

    this.ready = true
    this.createClusters()

    // Add event listener for zoom changes
    google.maps.event.addListener(this.map, "zoom_changed", () => {
      this.resetViewport()
      this.createClusters()
    })

    // Add event listener for map bounds changes
    google.maps.event.addListener(this.map, "bounds_changed", () => {
      this.resetViewport()
      this.createClusters()
    })
  }

  MarkerClusterer.prototype.addMarker = function (marker) {
    this.markers.push(marker)
    this.resetViewport()
    this.createClusters()
  }

  MarkerClusterer.prototype.clearMarkers = function () {
    this.resetViewport()
    this.markers = []
  }

  MarkerClusterer.prototype.resetViewport = function () {
    // Remove all clusters
    for (var i = 0; i < this.clusters.length; i++) {
      this.clusters[i].remove()
    }

    this.clusters = []

    // Reset all markers
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(null)
    }
  }

  MarkerClusterer.prototype.createClusters = function () {
    if (!this.ready) {
      return
    }

    var mapBounds = this.map.getBounds()
    var zoom = this.map.getZoom()

    // Skip clustering if zoom is too high
    if (zoom > this.maxZoom) {
      for (var i = 0; i < this.markers.length; i++) {
        this.markers[i].setMap(this.map)
      }
      return
    }

    // Group markers by proximity
    var clustered = {}

    for (var i = 0; i < this.markers.length; i++) {
      var marker = this.markers[i]
      var position = marker.getPosition()

      // Skip if marker is outside current view
      if (mapBounds && !mapBounds.contains(position)) {
        continue
      }

      // Calculate grid position
      var x = Math.floor(position.lat() * this.gridSize)
      var y = Math.floor(position.lng() * this.gridSize)
      var key = x + "_" + y

      if (!clustered[key]) {
        clustered[key] = []
      }

      clustered[key].push(marker)
    }

    // Create clusters for each group
    for (var key in clustered) {
      var markers = clustered[key]

      // Skip small clusters
      if (markers.length < this.minClusterSize) {
        for (var i = 0; i < markers.length; i++) {
          markers[i].setMap(this.map)
        }
        continue
      }

      // Create a cluster
      var cluster = new Cluster(this, markers)
      this.clusters.push(cluster)
    }
  }

  function Cluster(markerClusterer, markers) {
    this.markerClusterer = markerClusterer
    this.map = markerClusterer.map
    this.markers = markers || []
    this.center = this.calculateCenter()
    this.size = this.markers.length

    this.createClusterMarker()
  }

  Cluster.prototype.calculateCenter = function () {
    var latSum = 0
    var lngSum = 0
    var count = this.markers.length

    for (var i = 0; i < count; i++) {
      var position = this.markers[i].getPosition()
      latSum += position.lat()
      lngSum += position.lng()
    }

    return new google.maps.LatLng(latSum / count, lngSum / count)
  }

  Cluster.prototype.createClusterMarker = function () {
    

    // Hide individual markers
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(null)
    }

    // Determine cluster icon
    var index = Math.min(this.size, 5)
    var imageUrl = this.markerClusterer.imagePath + index + "." + this.markerClusterer.imageExtension

    // Create marker
    this.clusterMarker = new google.maps.Marker({
      position: this.center,
      map: this.map,
      icon: {
        url: imageUrl,
        scaledSize: new google.maps.Size(53, 53),
      },
      label: {
        text: this.size.toString(),
        color: "white",
        fontSize: "11px",
      },
    })

    // Add click listener
    google.maps.event.addListener(this.clusterMarker, "click", () => {
      var markers = this.markers
      var bounds = new google.maps.LatLngBounds()

      for (var i = 0; i < markers.length; i++) {
        bounds.extend(markers[i].getPosition())
      }

      this.map.fitBounds(bounds)

      // Zoom in more if cluster is small
      if (markers.length < 10 && this.map.getZoom() < 16) {
        this.map.setZoom(16)
      }
    })
  }

  Cluster.prototype.remove = function () {
    if (this.clusterMarker) {
      this.clusterMarker.setMap(null)
    }
  }
})()
