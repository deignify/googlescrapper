"use client"

import { Toaster } from "@/components/ui/toaster"

import { useState, useEffect, useRef, useMemo, useCallback } from "react"
import {
  Search,
  Download,
  Moon,
  Sun,
  Star,
  MapPin,
  Phone,
  Globe,
  MessageSquare,
  Check,
  AlertCircle,
  ImageIcon,
  Info,
  Eye,
  EyeOff,
  Loader2,
  RefreshCcw,
  DownloadCloud,
  FileSpreadsheet,
  FileIcon as FilePdf,
  Filter,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  SlidersHorizontal,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Contact,
  Copy,
  List,
  Map,
  Bookmark,
  History,
  Layers,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { LoginForm } from "@/components/login-form"
import { AuthProvider, useAuth } from "@/contexts/auth-context"
import { LogoutButton } from "@/components/logout-button"

// Add these imports at the top with the other imports
import { BookmarkedBusinesses } from "@/components/bookmarked-businesses"
import { SearchHistory } from "@/components/search-history"
import { HeatmapControls } from "@/components/heatmap-controls"
import { MapStyleControls } from "@/components/map-style-controls"
import { mapStyles, type MapStyleName } from "@/utils/map-styles"

// Default API key - empty string
const DEFAULT_API_KEY = ""
const RESULTS_PER_PAGE = 10 // Changed from 50 to 10
const TARGET_RESULTS_COUNT = 100 // Target to get 100+ results

// Extend the window interface to include google and MarkerClusterer
declare global {
  interface Window {
    google?: any
    MarkerClusterer?: any
    viewBusinessDetails: (placeId: string) => void
  }
}

// Helper function to format business types for display
const formatBusinessTypes = (types: string[]): string => {
  // Define primary business categories that should be prioritized
  const primaryCategories = [
    "restaurant",
    "cafe",
    "bar",
    "hotel",
    "lodging",
    "store",
    "shop",
    "bakery",
    "bank",
    "school",
    "university",
    "hospital",
    "doctor",
    "pharmacy",
    "gym",
    "spa",
    "beauty_salon",
    "hair_care",
    "supermarket",
    "grocery",
    "real_estate_agency",
    "lawyer",
    "accounting",
    "dentist",
    "clothing_store",
    "electronics_store",
    "furniture_store",
    "jewelry_store",
  ]

  // Filter out generic types
  const genericTypes = ["point_of_interest", "establishment", "place", "business"]
  const filteredTypes = types.filter((type) => !genericTypes.includes(type))

  // Sort types to prioritize primary business categories
  filteredTypes.sort((a, b) => {
    const aIsPrimary = primaryCategories.includes(a)
    const bIsPrimary = primaryCategories.includes(b)

    if (aIsPrimary && !bIsPrimary) return -1
    if (!aIsPrimary && bIsPrimary) return 1
    return 0
  })

  // Format the types for display
  return filteredTypes
    .map((type) => type.replace(/_/g, " "))
    .map((type) => type.charAt(0).toUpperCase() + type.slice(1))
    .join(", ")
}

// Helper function to format business categories
const formatBusinessCategories = (types: string[]): string => {
  // Define primary business categories that should be prioritized
  const primaryCategories = [
    "restaurant",
    "cafe",
    "bar",
    "hotel",
    "lodging",
    "store",
    "shop",
    "bakery",
    "bank",
    "school",
    "university",
    "hospital",
    "doctor",
    "pharmacy",
    "gym",
    "spa",
    "beauty_salon",
    "hair_care",
    "supermarket",
    "grocery",
    "real_estate_agency",
    "lawyer",
    "accounting",
    "dentist",
    "clothing_store",
    "electronics_store",
    "furniture_store",
    "jewelry_store",
  ]

  // Filter out generic types
  const genericTypes = ["point_of_interest", "establishment", "place", "business"]
  const filteredTypes = types.filter((type) => !genericTypes.includes(type))

  // Sort types to prioritize primary business categories
  filteredTypes.sort((a, b) => {
    const aIsPrimary = primaryCategories.includes(a)
    const bIsPrimary = primaryCategories.includes(b)

    if (aIsPrimary && !bIsPrimary) return -1
    if (!aIsPrimary && bIsPrimary) return 1
    return 0
  })

  // Format the types for display
  return filteredTypes
    .map((type) => type.replace(/_/g, " "))
    .map((type) => type.charAt(0).toUpperCase() + type.slice(1))
    .join(", ")
}

// Helper function to fetch business details
async function fetchBusinessDetails(apiKey: string, placeId: string): Promise<any | null> {
  try {
    // Generate a unique timestamp to prevent caching
    const timestamp = new Date().getTime()

    const response = await fetch(
      `/api/place-details?place_id=${placeId}&key=${encodeURIComponent(apiKey)}&_t=${timestamp}`,
      {
        headers: {
          "Cache-Control": "no-cache, no-store, must-revalidate",
          Pragma: "no-cache",
          Expires: "0",
        },
        cache: "no-store",
      },
    )

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    const data = await response.json()

    if (data.error) {
      throw new Error(data.error)
    }

    return data.result
  } catch (error) {
    console.error("Error fetching business details:", error)
    return null
  }
}

// Types
interface Business {
  place_id: string
  name: string
  formatted_address?: string
  vicinity?: string
  formatted_phone_number?: string
  website?: string
  rating?: number
  user_ratings_total?: number
  business_status?: string
  types?: string[]
  photos?: {
    photo_reference: string
    height: number
    width: number
  }[]
  opening_hours?: {
    open_now: boolean
  }
  url?: string
  geometry?: {
    location: {
      lat: number
      lng: number
    }
  }
}

interface BusinessDetails extends Business {
  reviews?: {
    author_name: string
    rating: number
    text: string
    time: number
  }[]
  opening_hours?: {
    open_now: boolean
    periods: any[]
    weekday_text: string[]
  }
  price_level?: number
  url?: string
  geometry?: {
    location: {
      lat: number
      lng: number
    }
  }
}

export default function GMBScraperWrapper() {
  return (
    <AuthProvider>
      <GMBScraper />
    </AuthProvider>
  )
}

function GMBScraper() {
  const { isAuthenticated, login } = useAuth()
  const { toast } = useToast()
  const [darkMode, setDarkMode] = useState(false)
  const [loading, setLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [apiKey, setApiKey] = useState(DEFAULT_API_KEY)
  const [businesses, setBusinesses] = useState<Business[]>([])
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null)
  const [selectedBusinessDetails, setSelectedBusinessDetails] = useState<BusinessDetails | null>(null)
  const [sortField, setSortField] = useState<string>("rating")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")
  const [showApiKey, setShowApiKey] = useState(false)
  const [apiError, setApiError] = useState<string | null>(null)
  const [showDebugPanel, setShowDebugPanel] = useState(false)
  const [debugResponse, setDebugResponse] = useState<string>("")
  const [directTestLoading, setDirectTestLoading] = useState(false)
  const [rawSearchResults, setRawSearchResults] = useState<any>(null)
  const [loadingMoreResults, setLoadingMoreResults] = useState(false)
  const [nextPageToken, setNextPageToken] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<"list" | "map">("list")
  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)
  const mapRef = useRef<google.maps.Map | null>(null)
  const markersRef = useRef<google.maps.Marker[]>([])
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const markerClustererRef = useRef<any>(null)

  // Add these state variables inside the GMBScraper component
  const [bookmarksOpen, setBookmarksOpen] = useState(false)
  const [searchHistoryOpen, setSearchHistoryOpen] = useState(false)
  const [mapControlsOpen, setMapControlsOpen] = useState(false)
  const [heatmapEnabled, setHeatmapEnabled] = useState(false)
  const [heatmapOptions, setHeatmapOptions] = useState({
    radius: 20,
    opacity: 0.7,
    intensity: 0.6,
    weightProperty: "default",
  })
  const [mapStyle, setMapStyle] = useState<MapStyleName>("standard")
  const heatmapRef = useRef<any>(null)

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)

  // Filter state
  const [filters, setFilters] = useState({
    claimed: "all", // "all", "claimed", "unclaimed"
    hasPhone: "all", // "all", "yes", "no"
    hasWebsite: "all", // "all", "yes", "no"
    minRating: 0, // 0-5
    maxRating: 5, // 0-5
    searchTerm: "", // Search within results
  })

  // Apply filters and sorting to businesses
  const filteredBusinesses = useMemo(() => {
    let result = [...businesses]

    // Apply filters
    if (filters.claimed !== "all") {
      result = result.filter((business) => {
        if (filters.claimed === "claimed") {
          return business.business_status === "OPERATIONAL"
        } else {
          return business.business_status !== "OPERATIONAL"
        }
      })
    }

    if (filters.hasPhone !== "all") {
      result = result.filter((business) => {
        // Check if formatted_phone_number exists and is not empty
        const hasPhone = business.formatted_phone_number && business.formatted_phone_number.trim() !== ""
        if (filters.hasPhone === "yes") {
          return hasPhone
        } else {
          return !hasPhone
        }
      })
    }

    if (filters.hasWebsite !== "all") {
      result = result.filter((business) => {
        // Check if website exists and is not empty
        const hasWebsite = business.website && business.website.trim() !== ""
        if (filters.hasWebsite === "yes") {
          return hasWebsite
        } else {
          return !hasWebsite
        }
      })
    }

    // Filter by rating range
    result = result.filter((business) => {
      const rating = business.rating || 0
      return rating >= filters.minRating && rating <= filters.maxRating
    })

    // Filter by search term
    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase()
      result = result.filter((business) => {
        return (
          business.name.toLowerCase().includes(searchLower) ||
          (business.formatted_address && business.formatted_address.toLowerCase().includes(searchLower)) ||
          (business.vicinity && business.vicinity.toLowerCase().includes(searchLower)) ||
          (business.types && business.types.some((type) => type.toLowerCase().includes(searchLower)))
        )
      })
    }

    // Apply sorting
    result.sort((a, b) => {
      let comparison = 0
      if (sortField === "rating") {
        comparison = (a.rating || 0) - (b.rating || 0)
      } else if (sortField === "reviews") {
        comparison = (a.user_ratings_total || 0) - (b.user_ratings_total || 0)
      } else if (sortField === "name") {
        comparison = a.name.localeCompare(b.name)
      }
      return sortDirection === "desc" ? -comparison : comparison
    })

    return result
  }, [businesses, filters, sortField, sortDirection])

  // Calculate pagination
  const totalPages = Math.ceil(filteredBusinesses.length / RESULTS_PER_PAGE)
  const paginatedBusinesses = useMemo(() => {
    const startIndex = (currentPage - 1) * RESULTS_PER_PAGE
    return filteredBusinesses.slice(startIndex, startIndex + RESULTS_PER_PAGE)
  }, [filteredBusinesses, currentPage])

  // Load API key from localStorage on component mount
  useEffect(() => {
    const savedKey = localStorage.getItem("gmb_api_key")
    if (savedKey) {
      setApiKey(savedKey)
    }
  }, [])

  // Reset pagination when businesses change
  useEffect(() => {
    setCurrentPage(1)
  }, [businesses])

  // Load Google Maps API
  useEffect(() => {
    if (!apiKey || mapLoaded) return

    const loadGoogleMapsAPI = () => {
      setMapError(null)

      // Check if Google Maps API is already loaded
      if (window.google && window.google.maps) {
        setMapLoaded(true)
        return
      }

      // Create script element to load Google Maps API
      const script = document.createElement("script")
      // Replace the script.src line in loadGoogleMapsAPI with:
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,marker,visualization&callback=initMap`
      script.async = true
      script.defer = true

      // Define callback function
      window.initMap = () => {
        setMapLoaded(true)
      }

      // Handle errors
      script.onerror = () => {
        setMapError("Failed to load Google Maps API. Please check your API key.")
      }

      document.head.appendChild(script)
    }

    loadGoogleMapsAPI()
  }, [apiKey, mapLoaded])

  // Initialize Google Map
  const initializeMap = useCallback(() => {
    if (!mapContainerRef.current || !window.google || !window.google.maps) return

    try {
      // Get center coordinates from businesses
      const bounds = new google.maps.LatLngBounds()
      let hasValidCoordinates = false

      // Check if we have valid coordinates in any business
      businesses.forEach((business) => {
        if (business.geometry && business.geometry.location) {
          const { lat, lng } = business.geometry.location
          if (typeof lat === "number" && typeof lng === "number") {
            bounds.extend({ lat, lng })
            hasValidCoordinates = true
          }
        }
      })

      // Default center if no valid coordinates
      const defaultCenter = { lat: 40.7128, lng: -74.006 } // New York City

      // Modify the initializeMap function to use the selected map style
      // Replace the mapOptions declaration with:
      const mapOptions: google.maps.MapOptions = {
        zoom: hasValidCoordinates ? 10 : 3,
        center: hasValidCoordinates ? bounds.getCenter() : defaultCenter,
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        zoomControl: true,
        styles: mapStyles[mapStyle],
      }

      mapRef.current = new window.google.maps.Map(mapContainerRef.current, mapOptions)

      // Fit bounds if we have valid coordinates
      if (hasValidCoordinates) {
        mapRef.current.fitBounds(bounds)

        // Adjust zoom level if too zoomed in
        const listener = google.maps.event.addListener(mapRef.current, "idle", () => {
          if (mapRef.current && mapRef.current.getZoom() > 16) {
            mapRef.current.setZoom(16)
          }
          google.maps.event.removeListener(listener)
        })
      }
    } catch (error) {
      console.error("Error initializing map:", error)
      setMapError("Failed to initialize map. Please try again.")
    }
  }, [businesses, darkMode, mapStyle])

  // Initialize map and add markers when map view is selected and API is loaded
  useEffect(() => {
    if (viewMode === "map" && mapLoaded && mapContainerRef.current && businesses.length > 0) {
      // First initialize the map
      initializeMap()
    }
  }, [viewMode, mapLoaded, businesses, initializeMap])

  // Add markers to map when map is initialized and filtered businesses change
  useEffect(() => {
    if (viewMode === "map" && mapRef.current && mapLoaded) {
      // Clear existing markers
      markersRef.current.forEach((marker) => marker.setMap(null))
      markersRef.current = []

      // Clear marker clusterer if it exists
      if (markerClustererRef.current) {
        markerClustererRef.current.clearMarkers()
      }

      // Create info window for marker clicks
      const infoWindow = new google.maps.InfoWindow()

      // Add markers for filtered businesses
      filteredBusinesses.forEach((business) => {
        if (business.geometry && business.geometry.location) {
          const { lat, lng } = business.geometry.location

          // Skip if coordinates are invalid
          if (typeof lat !== "number" || typeof lng !== "number") return

          // Create marker
          const marker = new google.maps.Marker({
            position: { lat, lng },
            map: mapRef.current,
            title: business.name,
            animation: google.maps.Animation.DROP,
          })

          // Create info window content
          const contentString = `
            <div style="max-width: 200px;">
              <h3 style="margin: 0 0 5px; font-size: 16px;">${business.name}</h3>
              ${
                business.rating
                  ? `
                <div style="display: flex; align-items: center; margin-bottom: 5px;">
                  <span style="color: #FFD700; margin-right: 5px;">★</span>
                  <span>${business.rating.toFixed(1)} (${business.user_ratings_total || 0})</span>
                </div>
              `
                  : ""
              }
              ${
                business.formatted_address
                  ? `
                <div style="margin-bottom: 5px; font-size: 12px;">${business.formatted_address}</div>
              `
                  : ""
              }
              ${
                business.formatted_phone_number
                  ? `
                <div style="margin-bottom: 5px; font-size: 12px;">📞 ${business.formatted_phone_number}</div>
              `
                  : ""
              }
              <button 
                style="background: #0070f3; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-top: 5px;"
                onclick="window.viewBusinessDetails('${business.place_id}')"
              >
                View Details
              </button>
            </div>
          `

          // Add click listener to marker
          marker.addListener("click", () => {
            infoWindow.setContent(contentString)
            infoWindow.open(mapRef.current, marker)
          })

          // Store marker reference
          markersRef.current.push(marker)
        }
      })

      // Add global function to view business details
      window.viewBusinessDetails = (placeId: string) => {
        const business = businesses.find((b) => b.place_id === placeId)
        if (business) {
          handleBusinessSelect(business)
        }
      }

      // Create marker clusterer if we have markers and the library is available
      if (markersRef.current.length > 0 && window.MarkerClusterer) {
        markerClustererRef.current = new window.MarkerClusterer(mapRef.current, markersRef.current, {
          imagePath: "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
        })
      }
    }
  }, [filteredBusinesses, viewMode, mapLoaded, businesses])

  const handleBusinessSelect = async (business: Business) => {
    setSelectedBusiness(business)

    // Fetch additional details if we don't have them yet
    if (business.place_id) {
      const details = await fetchBusinessDetails(apiKey, business.place_id)
      if (details) {
        setSelectedBusinessDetails(details)
      }
    }
  }

  // Handle page change
  const goToPage = (page: number) => {
    if (page < 1) page = 1
    if (page > totalPages) page = totalPages
    setCurrentPage(page)
  }

  // Reset filters
  const resetFilters = () => {
    setFilters({
      claimed: "all",
      hasPhone: "all",
      hasWebsite: "all",
      minRating: 0,
      maxRating: 5,
      searchTerm: "",
    })
    setCurrentPage(1)
  }

  // Handle sort change
  const handleSortChange = (field: string) => {
    if (field === sortField) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("desc") // Default to descending for new sort field
    }
  }

  // Fetch search results with pagination token
  const fetchWithPageToken = async (token: string) => {
    if (!apiKey.trim()) return null

    try {
      setLoadingMoreResults(true)
      // Generate a unique timestamp to prevent caching
      const timestamp = new Date().getTime()

      // Make a request with the page token
      const response = await fetch(
        `/api/search-with-token?key=${encodeURIComponent(apiKey)}&pagetoken=${encodeURIComponent(token)}&_t=${timestamp}`,
      )

      const responseText = await response.text()

      try {
        const data = JSON.parse(responseText)
        return data
      } catch (parseError) {
        console.error("Error parsing page token response:", parseError)
        return null
      }
    } catch (error) {
      console.error("Error fetching with page token:", error)
      return null
    } finally {
      setLoadingMoreResults(false)
    }
  }

  // Simplified search function that works more like the direct test
  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Error",
        description: "Please enter a search query",
        variant: "destructive",
      })
      return
    }

    if (!apiKey.trim()) {
      toast({
        title: "Error",
        description: "API key is required",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setBusinesses([])
    setApiError(null)
    setRawSearchResults(null)
    setShowDebugPanel(false)
    resetFilters()
    setNextPageToken(null)

    try {
      toast({
        title: "Searching...",
        description: `Query: "${searchQuery}"`,
      })

      // Save API key to localStorage
      localStorage.setItem("gmb_api_key", apiKey)

      // Generate a unique timestamp to prevent caching
      const timestamp = new Date().getTime()

      // Make a direct request to the Google Places API through our simplified route
      const response = await fetch(
        `/api/direct-test?key=${encodeURIComponent(apiKey)}&query=${encodeURIComponent(searchQuery)}&_t=${timestamp}`,
      )

      const responseText = await response.text()
      setDebugResponse(responseText)

      try {
        // Try to parse the response as JSON
        const data = JSON.parse(responseText)
        setRawSearchResults(data)

        // Check if the response contains results
        if (data.status === "OK" && data.results && data.results.length > 0) {
          // Set the businesses state with the results
          setBusinesses(data.results)

          // Add this line after setting businesses:
          saveSearchToHistory(searchQuery, data.results.length)

          // Save the next page token if available
          if (data.next_page_token) {
            setNextPageToken(data.next_page_token)
          }

          // Check if we need to fetch more results from related categories
          if (data.results.length < TARGET_RESULTS_COUNT) {
            // Get the most common business category from the results
            const categories = data.results.flatMap((b) => b.types || [])
            const categoryCounts = {}

            categories.forEach((category) => {
              if (!["point_of_interest", "establishment", "place", "business"].includes(category)) {
                categoryCounts[category] = (categoryCounts[category] || 0) + 1
              }
            })

            // Find the most common category
            let topCategory = null
            let maxCount = 0

            Object.entries(categoryCounts).forEach(([category, count]) => {
              if (count > maxCount) {
                maxCount = count as number
                topCategory = category
              }
            })

            // If we found a common category, fetch related results
            if (topCategory) {
              toast({
                title: "Fetching more results",
                description: `Looking for more businesses in the ${topCategory.replace(/_/g, " ")} category...`,
              })

              // Fetch related results after a short delay to allow the UI to update
              setTimeout(() => fetchRelatedResults(topCategory), 1000)
            }
          }

          toast({
            title: "Search completed",
            description: `Found ${data.results.length} businesses matching your criteria.`,
          })
        } else if (data.status === "ZERO_RESULTS") {
          setBusinesses([])
          toast({
            title: "No results found",
            description: `No businesses found for "${searchQuery}". Try a different search term.`,
            variant: "warning",
          })
        } else if (data.error_message) {
          throw new Error(data.error_message)
        } else {
          throw new Error(`API returned status: ${data.status}`)
        }
      } catch (parseError) {
        console.error("Error parsing response:", parseError)
        throw new Error("Failed to parse API response")
      }
    } catch (error) {
      console.error("Search error:", error)
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred"
      setApiError(errorMessage)
      toast({
        title: "Search failed",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const exportCSV = () => {
    if (businesses.length === 0) {
      toast({
        title: "Nothing to export",
        description: "There are no businesses to export",
        variant: "destructive",
      })
      return
    }

    // Prepare data for export
    const exportData = businesses.map((business) => ({
      "Business Name": business.name,
      Address: business.formatted_address || business.vicinity || "",
      Phone: business.formatted_phone_number || "",
      Website: business.website || "",
      Rating: business.rating || "N/A",
      Reviews: business.user_ratings_total || 0,
      Status: business.business_status === "OPERATIONAL" ? "Claimed" : "Unclaimed",
      Categories: business.types?.join(", ") || "",
    }))

    // Get headers from the first object
    const headers = Object.keys(exportData[0])

    // Create CSV content
    const csvContent = [
      headers.join(","), // Header row
      ...exportData.map((row) =>
        headers
          .map((header) => {
            // Handle values that need quotes (contain commas, quotes, or newlines)
            const value = String(row[header] || "")
            const needsQuotes = value.includes(",") || value.includes('"') || value.includes("\n")
            return needsQuotes ? `"${value.replace(/"/g, '""')}"` : value
          })
          .join(","),
      ),
    ].join("\n")

    // Create a blob and download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `gmb_data_${new Date().toISOString().slice(0, 10)}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Add this function after the exportCSV function
  const exportExcel = () => {
    if (businesses.length === 0) {
      toast({
        title: "Nothing to export",
        description: "There are no businesses to export",
        variant: "destructive",
      })
      return
    }

    // Prepare data for export
    const exportData = businesses.map((business) => ({
      "Business Name": business.name,
      Address: business.formatted_address || business.vicinity || "",
      Phone: business.formatted_phone_number || "",
      Website: business.website || "",
      Rating: business.rating || "N/A",
      Reviews: business.user_ratings_total || 0,
      Status: business.business_status === "OPERATIONAL" ? "Claimed" : "Unclaimed",
      Categories: business.types?.join(", ") || "",
    }))

    // Get headers from the first object
    const headers = Object.keys(exportData[0])

    // Create Excel XML content
    const xlsContent = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>GMB Data</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
      </head>
      <body>
        <table>
          <tr>
            ${headers.map((header) => `<th>${header}</th>`).join("")}
          </tr>
          ${exportData
            .map(
              (row) => `
            <tr>
              ${headers.map((header) => `<td>${row[header]}</td>`).join("")}
            </tr>
          `,
            )
            .join("")}
        </table>
      </body>
      </html>
    `

    // Create a blob and download link
    const blob = new Blob([xlsContent], { type: "application/vnd.ms-excel;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `gmb_data_${new Date().toISOString().slice(0, 10)}.xls`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Add this function for PDF export
  const exportToPDF = async (filtered = false) => {
    const dataToExport = filtered ? filteredBusinesses : businesses

    if (dataToExport.length === 0) {
      toast({
        title: "Nothing to export",
        description: "There are no businesses to export",
        variant: "destructive",
      })
      return
    }

    try {
      toast({
        title: "Generating HTML Report",
        description: "Please wait while we generate your report...",
      })

      // Prepare data for export with improved categories
      const exportData = dataToExport.map((business) => ({
        "Business Name": business.name,
        Address: business.formatted_address || business.vicinity || "",
        Phone: business.formatted_phone_number || "",
        Website: business.website || "",
        "Social Media": "", // Placeholder for social media
        Rating: business.rating || "N/A",
        Reviews: business.user_ratings_total || 0,
        Status: business.business_status === "OPERATIONAL" ? "Claimed" : "Unclaimed",
        Categories: formatBusinessCategories(business.types || []),
      }))

      // Create request data
      const requestData = {
        businesses: exportData,
        title: filtered ? "Filtered GMB Business Data" : "All GMB Business Data",
        query: searchQuery || "N/A",
        date: new Date().toLocaleDateString(),
        totalCount: exportData.length,
      }

      // Call the API to generate HTML report
      const response = await fetch("/api/generate-pdf", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      // Get the HTML blob
      const htmlBlob = await response.blob()

      // Create a download link
      const url = URL.createObjectURL(htmlBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `gmb_data_${filtered ? "filtered" : "all"}_${new Date().toISOString().slice(0, 10)}.html`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Report Generated",
        description: "Your HTML report has been generated and downloaded. Open it in a browser to view and print.",
      })
    } catch (error) {
      console.error("Error generating report:", error)
      toast({
        title: "Error",
        description: "Failed to generate report. Please try again.",
        variant: "destructive",
      })
    }
  }

  // New function to export contact information
  const exportContactInfo = () => {
    if (businesses.length === 0) {
      toast({
        title: "Nothing to export",
        description: "There are no businesses to export",
        variant: "destructive",
      })
      return
    }

    // Prepare data for export - focus on contact information
    const exportData = businesses.map((business) => ({
      "Business Name": business.name,
      Address: business.formatted_address || business.vicinity || "",
      Phone: business.formatted_phone_number || "",
      Website: business.website || "",
      "Google Maps URL": business.url || "",
      Status: business.business_status === "OPERATIONAL" ? "Claimed" : "Unclaimed",
      Categories: formatBusinessCategories(business.types || []),
    }))

    // Get headers from the first object
    const headers = Object.keys(exportData[0])

    // Create CSV content
    const csvContent = [
      headers.join(","), // Header row
      ...exportData.map((row) =>
        headers
          .map((header) => {
            // Handle values that need quotes (contain commas, quotes, or newlines)
            const value = String(row[header] || "")
            const needsQuotes = value.includes(",") || value.includes('"') || value.includes("\n")
            return needsQuotes ? `"${value.replace(/"/g, '""')}"` : value
          })
          .join(","),
      ),
    ].join("\n")

    // Create a blob and download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `business_contacts_${new Date().toISOString().slice(0, 10)}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Contact Information Exported",
      description: `Exported contact details for ${businesses.length} businesses.`,
    })
  }

  // Add a loadSampleData function
  const loadSampleData = () => {
    const sampleBusinesses: Business[] = [
      {
        place_id: "sample1",
        name: "Sample Restaurant",
        formatted_address: "123 Main St, Sample City",
        formatted_phone_number: "+1 555-123-456-7",
        website: "https://example.com",
        rating: 4.5,
        user_ratings_total: 123,
        business_status: "OPERATIONAL",
        types: ["restaurant", "food", "point_of_interest", "establishment"],
        photos: [
          {
            photo_reference: "sample_photo_1",
            height: 400,
            width: 400,
          },
        ],
        opening_hours: {
          open_now: true,
        },
        geometry: {
          location: {
            lat: 40.7128,
            lng: -74.006,
          },
        },
      },
      {
        place_id: "sample2",
        name: "Sample Store",
        formatted_address: "456 Market St, Sample City",
        business_status: "",
        types: ["store", "point_of_interest", "establishment"],
        rating: 3.8,
        user_ratings_total: 45,
        geometry: {
          location: {
            lat: 40.7148,
            lng: -74.009,
          },
        },
      },
      {
        place_id: "sample3",
        name: "Sample Hotel",
        formatted_address: "789 Broadway, Sample City",
        formatted_phone_number: "+1 555-987-6543",
        website: "https://samplehotel.com",
        rating: 4.2,
        user_ratings_total: 78,
        business_status: "OPERATIONAL",
        types: ["lodging", "hotel", "point_of_interest", "establishment"],
        geometry: {
          location: {
            lat: 40.7138,
            lng: -74.003,
          },
        },
      },
      {
        place_id: "sample4",
        name: "Sample Cafe",
        formatted_address: "321 Oak St, Sample City",
        formatted_phone_number: "+1 555-456-7890",
        rating: 4.7,
        user_ratings_total: 92,
        business_status: "",
        types: ["cafe", "food", "point_of_interest", "establishment"],
        geometry: {
          location: {
            lat: 40.7158,
            lng: -74.002,
          },
        },
      },
      {
        place_id: "sample5",
        name: "Sample Gym",
        formatted_address: "555 Fitness Ave, Sample City",
        website: "https://samplegym.com",
        rating: 4.0,
        user_ratings_total: 65,
        business_status: "OPERATIONAL",
        types: ["gym", "health", "point_of_interest", "establishment"],
        geometry: {
          location: {
            lat: 40.7168,
            lng: -74.004,
          },
        },
      },
      // Add more sample data to test pagination
      ...Array.from({ length: 120 }, (_, i) => ({
        place_id: `sample_extra_${i + 1}`,
        name: `Business ${i + 6}`,
        formatted_address: `${i + 100} Sample St, Sample City`,
        formatted_phone_number: i % 2 === 0 ? `+1 555-${i}00-${i}000` : undefined,
        website: i % 3 === 0 ? `https://example${i}.com` : undefined,
        rating: (i % 5) + 1,
        user_ratings_total: (i + 1) * 10,
        business_status: i % 2 === 0 ? "OPERATIONAL" : "",
        types: [
          i % 4 === 0 ? "restaurant" : i % 4 === 1 ? "store" : i % 4 === 2 ? "cafe" : "gym",
          "point_of_interest",
          "establishment",
        ],
        geometry: {
          location: {
            lat: 40.7128 + (Math.random() * 0.1 - 0.05),
            lng: -74.006 + (Math.random() * 0.1 - 0.05),
          },
        },
      })),
    ]

    setBusinesses(sampleBusinesses)

    toast({
      title: "Sample data loaded",
      description: `Loaded ${sampleBusinesses.length} sample businesses for testing`,
    })
  }

  // Add a direct test function that bypasses the API routes
  const runDirectTest = async () => {
    if (!apiKey.trim()) {
      toast({
        title: "Error",
        description: "API key is required",
        variant: "destructive",
      })
      return
    }

    setDirectTestLoading(true)
    setDebugResponse("")
    setRawSearchResults(null)

    try {
      const response = await fetch(`/api/direct-test?key=${encodeURIComponent(apiKey)}`)
      const text = await response.text()

      setDebugResponse(text)
      setShowDebugPanel(true)

      try {
        // Try to parse as JSON to see if it's a valid response
        const data = JSON.parse(text)
        setRawSearchResults(data)

        if (data.status === "OK" && data.results && data.results.length > 0) {
          toast({
            title: "API Key is Valid",
            description: `Direct test successful! Found ${data.results.length} results.`,
          })

          // Automatically load the results into the businesses state
          setBusinesses(data.results)

          // Save the next page token if available
          if (data.next_page_token) {
            setNextPageToken(data.next_page_token)
          }
        } else if (data.status === "ZERO_RESULTS") {
          toast({
            title: "No Results",
            description: "The API key is valid but returned no results for the test query.",
            variant: "warning",
          })
        } else if (data.error_message) {
          toast({
            title: "API Error",
            description: data.error_message,
            variant: "destructive",
          })
        }
      } catch (e) {
        toast({
          title: "Invalid Response",
          description: "Received an invalid response. Check the debug panel for details.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Direct test error:", error)
      setDebugResponse(error instanceof Error ? error.message : "Unknown error occurred")
      toast({
        title: "Test Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setDirectTestLoading(false)
    }
  }

  // Function to manually set businesses from the raw results
  const useRawResults = () => {
    if (rawSearchResults && rawSearchResults.results && rawSearchResults.results.length > 0) {
      setBusinesses(rawSearchResults.results)

      // Save the next page token if available
      if (rawSearchResults.next_page_token) {
        setNextPageToken(rawSearchResults.next_page_token)
      }

      toast({
        title: "Results Loaded",
        description: `Loaded ${rawSearchResults.results.length} businesses from raw results.`,
      })
    } else {
      toast({
        title: "No Raw Results",
        description: "There are no raw results to load.",
        variant: "warning",
      })
    }
  }

  // Add this function after the fetchBusinessDetails function:

  const fetchRelatedResults = async (category: string) => {
    if (!apiKey.trim() || !category) return

    try {
      setLoadingMoreResults(true)
      // Generate a unique timestamp to prevent caching
      const timestamp = new Date().getTime()

      // Create a query based on the category
      const query = `${category} in ${searchQuery.split(" in ")[1] || "United States"}`

      // Make a request to fetch related results
      const response = await fetch(
        `/api/direct-test?key=${encodeURIComponent(apiKey)}&query=${encodeURIComponent(query)}&_t=${timestamp}`,
      )

      const responseText = await response.text()

      try {
        const data = JSON.parse(responseText)

        if (data.status === "OK" && data.results && data.results.length > 0) {
          // Filter out businesses we already have
          const existingIds = businesses.map((b) => b.place_id)
          const newBusinesses = data.results.filter((b) => !existingIds.includes(b.place_id))

          if (newBusinesses.length > 0) {
            // Add the new businesses to our existing list
            setBusinesses((prev) => [...prev, ...newBusinesses])

            toast({
              title: "Additional results found",
              description: `Added ${newBusinesses.length} related businesses in the ${category} category.`,
            })

            // If we have a next page token, save it
            if (data.next_page_token) {
              setNextPageToken(data.next_page_token)
            }
          }
        }
      } catch (parseError) {
        console.error("Error parsing related results:", parseError)
      }
    } catch (error) {
      console.error("Error fetching related results:", error)
    } finally {
      setLoadingMoreResults(false)
    }
  }

  // Add this function to save a business to bookmarks
  const saveToBookmarks = (business: Business) => {
    // Get current bookmarks
    const savedBookmarks = localStorage.getItem("gmb_bookmarks")
    let bookmarks: Business[] = []

    if (savedBookmarks) {
      try {
        bookmarks = JSON.parse(savedBookmarks)
      } catch (error) {
        console.error("Error parsing bookmarks:", error)
      }
    }

    // Check if business is already bookmarked
    const isAlreadyBookmarked = bookmarks.some((b) => b.place_id === business.place_id)

    if (isAlreadyBookmarked) {
      toast({
        title: "Already bookmarked",
        description: "This business is already in your bookmarks",
      })
      return
    }

    // Add business to bookmarks
    bookmarks.push(business)
    localStorage.setItem("gmb_bookmarks", JSON.stringify(bookmarks))

    toast({
      title: "Bookmarked",
      description: "Business has been added to your bookmarks",
    })
  }

  // Add this function to save search to history
  const saveSearchToHistory = (query: string, resultCount: number) => {
    // Get current history
    const savedHistory = localStorage.getItem("gmb_search_history")
    let history: { query: string; timestamp: number; resultCount: number }[] = []

    if (savedHistory) {
      try {
        history = JSON.parse(savedHistory)
      } catch (error) {
        console.error("Error parsing search history:", error)
      }
    }

    // Remove existing entry with same query if exists
    history = history.filter((item) => item.query !== query)

    // Add new entry at the beginning
    history.unshift({
      query,
      timestamp: Date.now(),
      resultCount,
    })

    // Limit history to 20 items
    if (history.length > 20) {
      history = history.slice(0, 20)
    }

    localStorage.setItem("gmb_search_history", JSON.stringify(history))
  }

  // Add this function to toggle heatmap
  const toggleHeatmap = (enabled: boolean) => {
    setHeatmapEnabled(enabled)

    if (!enabled && heatmapRef.current) {
      heatmapRef.current.setMap(null)
      heatmapRef.current = null
      return
    }

    if (enabled && mapRef.current && window.google && filteredBusinesses.length > 0) {
      createHeatmap()
    }
  }

  // Add this function to update heatmap options
  const updateHeatmapOptions = (options: any) => {
    setHeatmapOptions(options)

    if (heatmapEnabled && heatmapRef.current) {
      createHeatmap()
    }
  }

  // Add this function to create heatmap
  const createHeatmap = () => {
    if (!window.google || !mapRef.current) return

    // Remove existing heatmap if any
    if (heatmapRef.current) {
      heatmapRef.current.setMap(null)
    }

    // Create heatmap data points
    const heatmapData = filteredBusinesses
      .filter((business) => business.geometry && business.geometry.location)
      .map((business) => {
        const { lat, lng } = business.geometry!.location

        // Calculate weight based on selected property
        let weight = 1
        if (heatmapOptions.weightProperty === "rating" && business.rating) {
          weight = business.rating / 5
        } else if (heatmapOptions.weightProperty === "reviews" && business.user_ratings_total) {
          // Normalize review count (0-1 scale)
          const maxReviews = Math.max(...filteredBusinesses.map((b) => b.user_ratings_total || 0))
          weight = maxReviews > 0 ? (business.user_ratings_total || 0) / maxReviews : 1
        }

        return {
          location: new google.maps.LatLng(lat, lng),
          weight: weight * heatmapOptions.intensity,
        }
      })

    // Create heatmap layer
    heatmapRef.current = new google.maps.visualization.HeatmapLayer({
      data: heatmapData,
      map: mapRef.current,
      radius: heatmapOptions.radius,
      opacity: heatmapOptions.opacity,
    })
  }

  // Add this useEffect to handle heatmap creation when filteredBusinesses or heatmap options change
  useEffect(() => {
    if (heatmapEnabled && mapRef.current && window.google && filteredBusinesses.length > 0) {
      // Add a small delay to ensure the map is fully loaded
      const timer = setTimeout(() => {
        createHeatmap()
      }, 100)

      return () => clearTimeout(timer)
    }
  }, [heatmapEnabled, filteredBusinesses, heatmapOptions, mapStyle])

  // All your existing state and functions
  const [query, setQuery] = useState("")
  const [location, setLocation] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [mapInstance, setMapInstance] = useState(null)
  const [markersArray, setMarkersArray] = useState([])
  const [markerClusterer, setMarkerClusterer] = useState(null)
  const [activeView, setActiveView] = useState("list")
  const [selectedCategories, setSelectedCategories] = useState([])
  const [ratingFilter, setRatingFilter] = useState(0)
  const [openNowFilter, setOpenNowFilter] = useState(false)
  const [heatmapLayer, setHeatmapLayer] = useState(null)
  const [showHeatmap, setShowHeatmap] = useState(false)
  const [bookmarkedBusinesses, setBookmarkedBusinesses] = useState([])
  const [searchHistory, setSearchHistory] = useState([])

  // Your existing useEffect hooks and functions

  // If not authenticated, show login form
  if (!isAuthenticated) {
    return <LoginForm onLoginSuccess={login} />
  }

  const loadMoreResults = async () => {
    if (!nextPageToken) return

    try {
      setLoadingMoreResults(true)
      const data = await fetchWithPageToken(nextPageToken)

      if (data && data.results) {
        // Append new results to existing businesses
        setBusinesses((prevBusinesses) => [...prevBusinesses, ...data.results])

        // Update next page token
        setNextPageToken(data.next_page_token || null)
      } else {
        // Clear next page token if no more results
        setNextPageToken(null)
      }
    } finally {
      setLoadingMoreResults(false)
    }
  }

  return (
    <div className={`min-h-screen ${darkMode ? "dark bg-gray-950" : "bg-gray-50"}`}>
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-2">
            <Search className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">GMB Scraper</h1>
            <Badge variant="outline" className="ml-2">
              Basic
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowDebugPanel(!showDebugPanel)}>
              Debug
            </Button>
            <Button variant="outline" size="sm" onClick={() => setBookmarksOpen(true)}>
              <Bookmark className="h-4 w-4 mr-1" />
              Bookmarks
            </Button>
            <Button variant="outline" size="sm" onClick={() => setSearchHistoryOpen(true)}>
              <History className="h-4 w-4 mr-1" />
              History
            </Button>
            {viewMode === "map" && (
              <Button variant="outline" size="sm" onClick={() => setMapControlsOpen(true)}>
                <Layers className="h-4 w-4 mr-1" />
                Map Controls
              </Button>
            )}
            <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)} className="rounded-full">
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <LogoutButton />
          </div>
        </header>

        {/* Search Section */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="grid gap-4">
              <div className="space-y-4">
                <Input
                  placeholder="Enter keyword (e.g., restaurant in New York)"
                  className="w-full"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />

                {/* API Key Input */}
                <div className="flex gap-2">
                  <Input
                    type={showApiKey ? "text" : "password"}
                    placeholder="Enter Google Maps API Key"
                    className="w-full"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                  <Button variant="outline" size="icon" onClick={() => setShowApiKey(!showApiKey)}>
                    {showApiKey ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </Button>
                </div>

                {apiError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>API Error</AlertTitle>
                    <AlertDescription>{apiError}</AlertDescription>
                  </Alert>
                )}

                <Alert variant="warning" className="bg-amber-50 dark:bg-amber-950/30">
                  <Info className="h-4 w-4" />
                  <AlertTitle>API Key Information</AlertTitle>
                  <AlertDescription>
                    Your API key must have the Places API enabled and proper billing set up in Google Cloud Console. For
                    deployed applications, make sure there are no API restrictions that would block requests from your
                    server.
                  </AlertDescription>
                </Alert>

                <div className="flex flex-wrap gap-2">
                  <Button onClick={handleSearch} disabled={loading} className="flex-1">
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Searching...</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Search className="h-4 w-4" />
                        <span>Search on Google Maps</span>
                      </div>
                    )}
                  </Button>
                  <Button variant="outline" onClick={runDirectTest} disabled={directTestLoading} className="flex-1">
                    {directTestLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Testing...</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <RefreshCcw className="h-4 w-4" />
                        <span>Direct API Test</span>
                      </div>
                    )}
                  </Button>
                  <Button variant="outline" onClick={loadSampleData} className="flex-1">
                    Load Sample Data
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Debug Panel */}
        {showDebugPanel && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Debug Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">API Response:</h3>
                  <Textarea
                    value={debugResponse}
                    readOnly
                    className="font-mono text-xs h-64 overflow-auto"
                    placeholder="Run a direct API test to see the response here..."
                  />
                </div>

                {rawSearchResults && rawSearchResults.results && rawSearchResults.results.length > 0 && (
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-sm">Raw results contain {rawSearchResults.results.length} businesses.</span>
                    </div>
                    <Button variant="outline" size="sm" onClick={useRawResults}>
                      Use These Results
                    </Button>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button variant="outline" size="sm" onClick={() => setShowDebugPanel(false)}>
                    Close Debug Panel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filter and Results Count */}
        {businesses.length > 0 && (
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Showing {paginatedBusinesses.length} of {filteredBusinesses.length} businesses
                {filteredBusinesses.length !== businesses.length && ` (filtered from ${businesses.length})`}
              </span>

              {/* Load more results button */}
              {nextPageToken && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={loadMoreResults}
                  disabled={loadingMoreResults}
                  className="ml-2"
                >
                  {loadingMoreResults ? (
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                  ) : (
                    <RefreshCcw className="h-3 w-3 mr-1" />
                  )}
                  Load More Results
                </Button>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              {/* View toggle */}
              <ToggleGroup
                type="single"
                value={viewMode}
                onValueChange={(value) => value && setViewMode(value as "list" | "map")}
              >
                <ToggleGroupItem value="list" aria-label="List View">
                  <List className="h-4 w-4 mr-1" />
                  List
                </ToggleGroupItem>
                <ToggleGroupItem value="map" aria-label="Map View">
                  <Map className="h-4 w-4 mr-1" />
                  Map
                </ToggleGroupItem>
              </ToggleGroup>

              {/* Search within results */}
              <div className="relative w-full sm:w-auto">
                <Input
                  placeholder="Search within results"
                  value={filters.searchTerm}
                  onChange={(e) => setFilters({ ...filters, searchTerm: e.target.value })}
                  className="w-full sm:w-auto pr-8"
                />
                <Search className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>

              {/* Filter dropdown */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-4">
                    <h4 className="font-medium">Filter Options</h4>

                    <div className="space-y-2">
                      <Label>Business Status</Label>
                      <Select
                        value={filters.claimed}
                        onValueChange={(value) => setFilters({ ...filters, claimed: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Businesses</SelectItem>
                          <SelectItem value="claimed">Claimed Only</SelectItem>
                          <SelectItem value="unclaimed">Unclaimed Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Has Phone Number</Label>
                      <Select
                        value={filters.hasPhone}
                        onValueChange={(value) => setFilters({ ...filters, hasPhone: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Businesses</SelectItem>
                          <SelectItem value="yes">With Phone Number</SelectItem>
                          <SelectItem value="no">Without Phone Number</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Has Website</Label>
                      <Select
                        value={filters.hasWebsite}
                        onValueChange={(value) => setFilters({ ...filters, hasWebsite: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Businesses</SelectItem>
                          <SelectItem value="yes">With Website</SelectItem>
                          <SelectItem value="no">Without Website</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Rating Range</Label>
                      <div className="flex items-center gap-2">
                        <Select
                          value={filters.minRating.toString()}
                          onValueChange={(value) => setFilters({ ...filters, minRating: Number(value) })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Min" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="0">0+</SelectItem>
                            <SelectItem value="1">1+</SelectItem>
                            <SelectItem value="2">2+</SelectItem>
                            <SelectItem value="3">3+</SelectItem>
                            <SelectItem value="4">4+</SelectItem>
                            <SelectItem value="4.5">4.5+</SelectItem>
                          </SelectContent>
                        </Select>
                        <span>to</span>
                        <Select
                          value={filters.maxRating.toString()}
                          onValueChange={(value) => setFilters({ ...filters, maxRating: Number(value) })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Max" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">Up to 1</SelectItem>
                            <SelectItem value="2">Up to 2</SelectItem>
                            <SelectItem value="3">Up to 3</SelectItem>
                            <SelectItem value="4">Up to 4</SelectItem>
                            <SelectItem value="5">Up to 5</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button onClick={resetFilters} variant="outline" className="w-full">
                      Reset Filters
                    </Button>

                    {/* Debug button */}
                    <Button
                      onClick={() => {
                        // Count businesses with phone numbers and websites
                        const withPhone = businesses.filter(
                          (b) => b.formatted_phone_number && b.formatted_phone_number.trim() !== "",
                        ).length
                        const withWebsite = businesses.filter((b) => b.website && b.website.trim() !== "").length
                        const claimed = businesses.filter((b) => b.business_status === "OPERATIONAL").length

                        toast({
                          title: "Filter Debug Info",
                          description: `Total: ${businesses.length}, With Phone: ${withPhone}, With Website: ${withWebsite}, Claimed: ${claimed}`,
                        })
                      }}
                      variant="ghost"
                      className="w-full mt-2 text-xs"
                    >
                      Debug Filters
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Sort dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Sort
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Sort By</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleSortChange("name")} className="flex justify-between">
                    Business Name
                    {sortField === "name" &&
                      (sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />)}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleSortChange("rating")} className="flex justify-between">
                    Rating
                    {sortField === "rating" &&
                      (sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />)}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleSortChange("reviews")} className="flex justify-between">
                    Reviews Count
                    {sortField === "reviews" &&
                      (sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />)}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        )}

        {/* Results View - List or Map */}
        {businesses.length > 0 ? (
          <>
            {viewMode === "list" ? (
              /* List View */
              <Card className="mb-6 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="px-4 py-3 text-left font-medium text-sm">
                          <div
                            className="flex items-center gap-1 cursor-pointer"
                            onClick={() => handleSortChange("name")}
                          >
                            Business Name
                            {sortField === "name" ? (
                              sortDirection === "asc" ? (
                                <ArrowUp className="h-3 w-3" />
                              ) : (
                                <ArrowDown className="h-3 w-3" />
                              )
                            ) : (
                              <ArrowUpDown className="h-3 w-3 text-muted-foreground" />
                            )}
                          </div>
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Address</th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Phone</th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Website</th>
                        <th className="px-4 py-3 text-left font-medium text-sm">
                          <div
                            className="flex items-center gap-1 cursor-pointer"
                            onClick={() => handleSortChange("rating")}
                          >
                            Rating
                            {sortField === "rating" ? (
                              sortDirection === "asc" ? (
                                <ArrowUp className="h-3 w-3" />
                              ) : (
                                <ArrowDown className="h-3 w-3" />
                              )
                            ) : (
                              <ArrowUpDown className="h-3 w-3 text-muted-foreground" />
                            )}
                          </div>
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-sm">
                          <div
                            className="flex items-center gap-1 cursor-pointer"
                            onClick={() => handleSortChange("reviews")}
                          >
                            Reviews
                            {sortField === "reviews" ? (
                              sortDirection === "asc" ? (
                                <ArrowUp className="h-3 w-3" />
                              ) : (
                                <ArrowDown className="h-3 w-3" />
                              )
                            ) : (
                              <ArrowUpDown className="h-3 w-3 text-muted-foreground" />
                            )}
                          </div>
                        </th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Status</th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Categories</th>
                        <th className="px-4 py-3 text-left font-medium text-sm">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedBusinesses.length > 0 ? (
                        paginatedBusinesses.map((business) => (
                          <tr key={business.place_id} className="border-b hover:bg-muted/50">
                            <td className="px-4 py-3">
                              <button
                                className="font-medium text-left hover:text-primary hover:underline w-full"
                                onClick={() => handleBusinessSelect(business)}
                              >
                                {business.name}
                              </button>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-start gap-1 text-sm">
                                <MapPin className="h-4 w-4 shrink-0 mt-0.5 text-muted-foreground" />
                                <span>{business.formatted_address || business.vicinity || "N/A"}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              {business.formatted_phone_number ? (
                                <div className="flex items-center gap-1 text-sm">
                                  <Phone className="h-4 w-4 text-muted-foreground" />
                                  <span>{business.formatted_phone_number}</span>
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">N/A</span>
                              )}
                            </td>
                            <td className="px-4 py-3">
                              {business.website ? (
                                <div className="flex items-center gap-1 text-sm">
                                  <Globe className="h-4 w-4 text-muted-foreground" />
                                  <a
                                    href={business.website}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-primary hover:underline truncate max-w-[150px]"
                                  >
                                    {business.website.replace(/^https?:\/\/(www\.)?/, "")}
                                  </a>
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">N/A</span>
                              )}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-1">
                                {business.rating ? (
                                  <>
                                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                    <span>{business.rating.toFixed(1)}</span>
                                  </>
                                ) : (
                                  <span className="text-muted-foreground">N/A</span>
                                )}
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-1">
                                <MessageSquare className="h-4 w-4 text-muted-foreground" />
                                <span>{business.user_ratings_total || 0}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              {business.business_status === "OPERATIONAL" ? (
                                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                  <Check className="h-3 w-3 mr-1" /> Claimed
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                                  <AlertCircle className="h-3 w-3 mr-1" /> Unclaimed
                                </Badge>
                              )}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex flex-wrap gap-1">
                                {business.types &&
                                  formatBusinessTypes(business.types)
                                    .split(", ")
                                    .slice(0, 3)
                                    .map((type, index) => (
                                      <Badge key={index} variant="secondary" className="text-xs">
                                        {type}
                                      </Badge>
                                    ))}
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleBusinessSelect(business)}
                                className="h-8 px-2"
                              >
                                <Search className="h-3.5 w-3.5" />
                              </Button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">
                            {businesses.length > 0
                              ? "No businesses found matching your filters."
                              : "Search for businesses to see results here."}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                {filteredBusinesses.length > RESULTS_PER_PAGE && (
                  <CardFooter className="flex items-center justify-between px-6 py-4 border-t">
                    <div className="text-sm text-muted-foreground">
                      Page {currentPage} of {totalPages}
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => goToPage(1)}
                        disabled={currentPage === 1}
                        className="h-8 w-8"
                      >
                        <ChevronsLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => goToPage(currentPage - 1)}
                        disabled={currentPage === 1}
                        className="h-8 w-8"
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>

                      {/* Page numbers */}
                      <div className="flex items-center gap-1 mx-2">
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                          // Calculate which page numbers to show
                          let pageNum = i + 1
                          if (totalPages > 5) {
                            if (currentPage <= 3) {
                              pageNum = i + 1
                            } else if (currentPage >= totalPages - 2) {
                              pageNum = totalPages - 4 + i
                            } else {
                              pageNum = currentPage - 2 + i
                            }
                          }

                          return (
                            <Button
                              key={i}
                              variant={currentPage === pageNum ? "default" : "outline"}
                              size="icon"
                              onClick={() => goToPage(pageNum)}
                              className="h-8 w-8"
                            >
                              {pageNum}
                            </Button>
                          )
                        })}
                      </div>

                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => goToPage(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        className="h-8 w-8"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => goToPage(totalPages)}
                        disabled={currentPage === totalPages}
                        className="h-8 w-8"
                      >
                        <ChevronsRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            ) : (
              /* Map View */
              <Card className="mb-6 overflow-hidden">
                <CardContent className="p-0">
                  {mapLoaded ? (
                    <div ref={mapContainerRef} className="w-full h-[600px] relative">
                      {/* Map will be rendered here */}
                    </div>
                  ) : (
                    <div className="w-full h-[600px] flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                      {mapError ? (
                        <div className="text-center p-6">
                          <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-4" />
                          <h3 className="text-lg font-medium mb-2">Failed to load map</h3>
                          <p className="text-muted-foreground">{mapError}</p>
                          <Button
                            variant="outline"
                            className="mt-4"
                            onClick={() => setMapLoaded(false)} // Reset to try loading again
                          >
                            Try Again
                          </Button>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Loader2 className="h-10 w-10 animate-spin mx-auto mb-4" />
                          <p>Loading map...</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between items-center py-3 border-t">
                  <div className="text-sm text-muted-foreground">
                    Showing {filteredBusinesses.length} businesses on map
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (mapRef.current && markersRef.current.length > 0) {
                          const bounds = new google.maps.LatLngBounds()
                          markersRef.current.forEach((marker) => {
                            if (marker.getPosition()) {
                              bounds.extend(marker.getPosition()!)
                            }
                          })
                          mapRef.current.fitBounds(bounds)
                        }
                      }}
                    >
                      Fit All Markers
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            )}
          </>
        ) : (
          <Card className="mb-6">
            <CardContent className="py-10 text-center">
              <Search className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">No businesses found</h3>
              <p className="text-muted-foreground">
                Search for businesses using the search bar above or load sample data to get started.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Export Options */}
        <div className="mb-8">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" disabled={businesses.length === 0}>
                <DownloadCloud className="h-4 w-4 mr-2" />
                Export Options
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Export Format</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => exportToPDF(false)}>
                <FilePdf className="h-4 w-4 mr-2" />
                Export All to HTML Report
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportToPDF(true)}>
                <FilePdf className="h-4 w-4 mr-2" />
                Export Filtered to HTML Report
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={exportExcel}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Download as Excel
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportCSV}>
                <Download className="h-4 w-4 mr-2" />
                Download as CSV
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={exportContactInfo}>
                <Contact className="h-4 w-4 mr-2" />
                Export Contact Information
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Detail View Sheet */}
        <Sheet
          open={!!selectedBusiness}
          onOpenChange={() => {
            setSelectedBusiness(null)
            setSelectedBusinessDetails(null)
          }}
        >
          <SheetContent className="sm:max-w-xl overflow-y-auto">
            {selectedBusiness && (
              <>
                <SheetHeader>
                  <SheetTitle>{selectedBusiness.name}</SheetTitle>
                  <SheetDescription>
                    <div className="flex items-center gap-2 mt-1">
                      {selectedBusiness.rating ? (
                        <>
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span>
                            {selectedBusiness.rating.toFixed(1)} ({selectedBusiness.user_ratings_total || 0} reviews)
                          </span>
                        </>
                      ) : (
                        <span>No ratings yet</span>
                      )}
                      {selectedBusiness.business_status === "OPERATIONAL" ? (
                        <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
                          <Check className="h-3 w-3 mr-1" /> Claimed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="ml-2 bg-amber-50 text-amber-700 border-amber-200">
                          <AlertCircle className="h-3 w-3 mr-1" /> Unclaimed
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-start gap-1 mt-2 text-sm">
                      <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
                      <span>
                        {selectedBusiness.formatted_address || selectedBusiness.vicinity || "Address not available"}
                      </span>
                    </div>
                    {selectedBusinessDetails?.formatted_phone_number && (
                      <div className="flex items-center gap-1 mt-2 text-sm">
                        <Phone className="h-4 w-4" />
                        <span>{selectedBusinessDetails.formatted_phone_number}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 ml-1"
                          onClick={() => {
                            navigator.clipboard.writeText(selectedBusinessDetails.formatted_phone_number)
                            toast({
                              title: "Copied to clipboard",
                              description: "Phone number copied to clipboard",
                            })
                          }}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    {selectedBusinessDetails?.website && (
                      <div className="flex items-center gap-1 mt-2 text-sm">
                        <Globe className="h-4 w-4" />
                        <a
                          href={selectedBusinessDetails.website}
                          className="text-primary hover:underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {selectedBusinessDetails.website}
                        </a>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 ml-1"
                          onClick={() => {
                            navigator.clipboard.writeText(selectedBusinessDetails.website)
                            toast({
                              title: "Copied to clipboard",
                              description: "Website URL copied to clipboard",
                            })
                          }}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-1 mt-3">
                      {selectedBusiness.types?.map((type, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {type.replace(/_/g, " ")}
                        </Badge>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2"
                      onClick={() => saveToBookmarks(selectedBusiness)}
                    >
                      <Bookmark className="h-4 w-4 mr-1" />
                      Save Business
                    </Button>
                  </SheetDescription>
                </SheetHeader>

                <Tabs defaultValue="details" className="mt-6">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="details">
                      <Globe className="h-4 w-4 mr-2" />
                      Details
                    </TabsTrigger>
                    <TabsTrigger value="reviews">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Reviews
                    </TabsTrigger>
                    <TabsTrigger value="images">
                      <ImageIcon className="h-4 w-4 mr-2" />
                      Images
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="details" className="mt-4 space-y-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="space-y-4">
                          {selectedBusinessDetails?.opening_hours && (
                            <div>
                              <h4 className="font-medium mb-2">Opening Hours</h4>
                              <div className="grid gap-1 text-sm">
                                {selectedBusinessDetails.opening_hours.weekday_text?.map((day, index) => (
                                  <div key={index} className="flex justify-between">
                                    <span>{day.split(": ")[0]}:</span>
                                    <span>{day.split(": ")[1]}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {selectedBusinessDetails?.price_level && (
                            <div>
                              <h4 className="font-medium mb-2">Price Level</h4>
                              <div className="flex">
                                {Array.from({ length: 4 }).map((_, i) => (
                                  <span
                                    key={i}
                                    className={`text-lg ${i < selectedBusinessDetails.price_level ? "text-green-600" : "text-gray-300"}`}
                                  >
                                    $
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {selectedBusinessDetails?.url && (
                            <div>
                              <h4 className="font-medium mb-2">Google Maps</h4>
                              <a
                                href={selectedBusinessDetails.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-primary hover:underline flex items-center gap-2"
                              >
                                <MapPin className="h-4 w-4" />
                                View on Google Maps
                              </a>
                            </div>
                          )}

                          {selectedBusinessDetails?.geometry?.location && (
                            <div>
                              <h4 className="font-medium mb-2">Location</h4>
                              <div className="h-[200px] w-full rounded-md overflow-hidden border mt-2">
                                <div
                                  id="detail-map"
                                  className="w-full h-full"
                                  ref={(el) => {
                                    if (
                                      el &&
                                      window.google &&
                                      window.google.maps &&
                                      selectedBusinessDetails?.geometry?.location
                                    ) {
                                      const { lat, lng } = selectedBusinessDetails.geometry.location
                                      const map = new window.google.maps.Map(el, {
                                        center: { lat, lng },
                                        zoom: 15,
                                        mapTypeControl: false,
                                        streetViewControl: false,
                                        fullscreenControl: false,
                                      })
                                      new window.google.maps.Marker({
                                        position: { lat, lng },
                                        map,
                                        title: selectedBusinessDetails.name,
                                      })
                                    }
                                  }}
                                ></div>
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="reviews" className="mt-4 space-y-4">
                    {selectedBusinessDetails?.reviews?.length ? (
                      selectedBusinessDetails.reviews.map((review, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div className="font-medium">{review.author_name}</div>
                            <div className="text-sm text-muted-foreground">
                              {new Date(review.time * 1000).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="flex items-center mt-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                          <p className="mt-2 text-sm">{review.text}</p>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        No reviews available for this business.
                      </div>
                    )}
                  </TabsContent>
                  <TabsContent value="images" className="mt-4">
                    {selectedBusiness.photos?.length ? (
                      <div className="grid grid-cols-2 gap-2">
                        {selectedBusiness.photos.map((photo, index) => (
                          <div key={index} className="aspect-square rounded-lg overflow-hidden border">
                            <img
                              src={`https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photo.photo_reference}&key=${apiKey}`}
                              alt={`${selectedBusiness.name} photo ${index + 1}`}
                              className="h-full w-full object-cover"
                              onError={(e) => {
                                ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=400&width=400"
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        No images available for this business.
                      </div>
                    )}
                  </TabsContent>
                </Tabs>

                <div className="flex justify-end mt-8">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedBusiness(null)
                      setSelectedBusinessDetails(null)
                    }}
                  >
                    Close
                  </Button>
                </div>
              </>
            )}
          </SheetContent>
        </Sheet>

        {/* Bookmarks Sheet */}
        <Sheet open={bookmarksOpen} onOpenChange={setBookmarksOpen}>
          <SheetContent className="sm:max-w-md">
            <SheetHeader>
              <SheetTitle>Bookmarked Businesses</SheetTitle>
              <SheetDescription>View and manage your saved businesses</SheetDescription>
            </SheetHeader>
            <div className="mt-6">
              <BookmarkedBusinesses
                onSelectBusiness={(business) => {
                  handleBusinessSelect(business)
                  setBookmarksOpen(false)
                }}
              />
            </div>
          </SheetContent>
        </Sheet>

        {/* Search History Sheet */}
        <Sheet open={searchHistoryOpen} onOpenChange={setSearchHistoryOpen}>
          <SheetContent className="sm:max-w-md">
            <SheetHeader>
              <SheetTitle>Search History</SheetTitle>
              <SheetDescription>View and reuse your previous searches</SheetDescription>
            </SheetHeader>
            <div className="mt-6">
              <SearchHistory
                onSelectQuery={(query) => {
                  setSearchQuery(query)
                  setSearchHistoryOpen(false)
                  // Auto-search after a short delay
                  setTimeout(() => {
                    handleSearch()
                  }, 300)
                }}
              />
            </div>
          </SheetContent>
        </Sheet>

        {/* Map Controls Sheet */}
        <Sheet open={mapControlsOpen} onOpenChange={setMapControlsOpen}>
          <SheetContent className="sm:max-w-md overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Map Controls</SheetTitle>
              <SheetDescription>Customize map visualization options</SheetDescription>
            </SheetHeader>
            <div className="mt-6 space-y-6">
              <HeatmapControls
                enabled={heatmapEnabled}
                onToggleHeatmap={toggleHeatmap}
                onUpdateHeatmapOptions={updateHeatmapOptions}
              />

              <MapStyleControls currentStyle={mapStyle} onStyleChange={setMapStyle} />
            </div>
          </SheetContent>
        </Sheet>

        <Toaster />
      </div>
    </div>
  )
}
