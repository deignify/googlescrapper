import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const placeId = searchParams.get("place_id")
  const key = searchParams.get("key")
  const timestamp = searchParams.get("_t") || Date.now().toString()

  if (!key) {
    return NextResponse.json({ error: "API key is required" }, { status: 400 })
  }

  if (!placeId) {
    return NextResponse.json({ error: "Place ID is required" }, { status: 400 })
  }

  try {
    // Build the URL for the Google Places API Details request
    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&key=${encodeURIComponent(key)}&fields=name,formatted_address,formatted_phone_number,website,rating,user_ratings_total,business_status,types,photos,opening_hours,reviews,price_level,url,geometry&_nocache=${timestamp}`

    // Make request to Google Places API
    const response = await fetch(url, {
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Google API returned ${response.status}: ${errorText}`)
    }

    const data = await response.json()

    // Check for API errors
    if (data.status !== "OK") {
      return NextResponse.json(
        {
          error: `Google API error: ${data.status} - ${data.error_message || "Unknown error"}`,
          details: data,
        },
        { status: 500 },
      )
    }

    return NextResponse.json(data)
  } catch (error) {
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "An unknown error occurred",
      },
      { status: 500 },
    )
  }
}
