import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const key = searchParams.get("key")
  const query = searchParams.get("query") || "restaurants in New York"

  if (!key) {
    return NextResponse.json({ error: "API key is required" }, { status: 400 })
  }

  try {
    // Log the request
    console.log("Direct test API request received with key length:", key.length)
    console.log("Query:", query)

    // Make a request to the Google Places API with more fields
    const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${encodeURIComponent(key)}&fields=formatted_address,name,rating,opening_hours,geometry,icon,id,place_id,plus_code,reference,types,user_ratings_total,price_level,business_status,photos,formatted_phone_number,website&radius=50000&maxresults=100`

    console.log("Making direct test request to Google API")

    // Make the request with full error details
    const response = await fetch(url, {
      headers: {
        "Cache-Control": "no-cache",
        "Content-Type": "application/json",
      },
    })

    // Get the raw response text
    const responseText = await response.text()
    console.log("Google API raw response length:", responseText.length)

    // Parse the response to JSON
    const data = JSON.parse(responseText)

    // If we have results, fetch additional details for each place
    if (data.status === "OK" && data.results && data.results.length > 0) {
      // Process up to 10 results at a time to avoid rate limiting
      const batchSize = 10
      const batches = Math.ceil(data.results.length / batchSize)

      for (let i = 0; i < batches; i++) {
        const startIdx = i * batchSize
        const endIdx = Math.min(startIdx + batchSize, data.results.length)
        const batch = data.results.slice(startIdx, endIdx)

        // Process each place in the batch
        const detailPromises = batch.map(async (place) => {
          try {
            // Only fetch details if we have a place_id
            if (place.place_id) {
              const detailUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=formatted_phone_number,website&key=${encodeURIComponent(key)}`
              const detailResponse = await fetch(detailUrl)
              const detailData = await detailResponse.json()

              // If we got valid details, add them to the place object
              if (detailData.status === "OK" && detailData.result) {
                if (detailData.result.formatted_phone_number) {
                  place.formatted_phone_number = detailData.result.formatted_phone_number
                }
                if (detailData.result.website) {
                  place.website = detailData.result.website
                }
              }
            }
            return place
          } catch (error) {
            console.error(`Error fetching details for place ${place.name}:`, error)
            return place // Return the original place if there's an error
          }
        })

        // Wait for all details in this batch to be fetched
        await Promise.all(detailPromises)

        // Add a small delay between batches to avoid rate limiting
        if (i < batches - 1) {
          await new Promise((resolve) => setTimeout(resolve, 200))
        }
      }
    }

    // Return the enhanced data
    return new Response(JSON.stringify(data), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    })
  } catch (error) {
    console.error("Direct test error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : null,
      },
      { status: 500 },
    )
  }
}
