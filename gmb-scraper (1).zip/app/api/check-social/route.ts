import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const url = searchParams.get("url")

  if (!url) {
    return NextResponse.json({ error: "URL parameter is required" }, { status: 400 })
  }

  try {
    // This is a simplified implementation for demo purposes
    // In a real implementation, you would:
    // 1. Fetch the HTML of the website
    // 2. Parse it to look for social media links
    // 3. Return the found links

    // For this demo, we'll simulate finding social media links with a random approach
    // to demonstrate the functionality without actually scraping websites

    const socialMedia = {
      hasSocial: Math.random() > 0.3, // 70% chance of having social media
    }

    if (socialMedia.hasSocial) {
      // Add random social media platforms
      if (Math.random() > 0.4)
        socialMedia["facebook"] = `https://facebook.com/${url.replace(/https?:\/\/(www\.)?/, "").split("/")[0]}`
      if (Math.random() > 0.5)
        socialMedia["twitter"] = `https://twitter.com/${url.replace(/https?:\/\/(www\.)?/, "").split("/")[0]}`
      if (Math.random() > 0.6)
        socialMedia["instagram"] = `https://instagram.com/${url.replace(/https?:\/\/(www\.)?/, "").split("/")[0]}`
      if (Math.random() > 0.7)
        socialMedia["linkedin"] = `https://linkedin.com/company/${url.replace(/https?:\/\/(www\.)?/, "").split("/")[0]}`
    }

    return NextResponse.json(socialMedia)
  } catch (error) {
    console.error("Error checking social media:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "An unknown error occurred", hasSocial: false },
      { status: 500 },
    )
  }
}
