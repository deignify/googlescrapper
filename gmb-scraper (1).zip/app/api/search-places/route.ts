import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("query")
  const pagetoken = searchParams.get("pagetoken")
  const key = searchParams.get("key")
  const timestamp = searchParams.get("_t") || Date.now().toString()

  // Add more detailed logging for deployment debugging
  console.log("API Request received in production:", {
    hasQuery: !!query,
    hasPageToken: !!pagetoken,
    hasKey: !!key,
    timestamp,
    query: query ? `${query.substring(0, 20)}...` : null,
    url: request.url,
    headers: Object.fromEntries(request.headers),
  })

  if (!key) {
    console.error("API key missing in request")
    return NextResponse.json({ error: "API key is required" }, { status: 400 })
  }

  if (!query && !pagetoken) {
    console.error("Both query and pagetoken missing in request")
    return NextResponse.json({ error: "Query or pagetoken parameter is required" }, { status: 400 })
  }

  try {
    // Build the URL based on whether we're using a query or a page token
    let url = "https://maps.googleapis.com/maps/api/place/textsearch/json?"

    if (pagetoken) {
      url += `pagetoken=${encodeURIComponent(pagetoken)}&key=${encodeURIComponent(key)}`
    } else {
      url += `query=${encodeURIComponent(query || "")}&key=${encodeURIComponent(key)}`
    }

    // Add extra parameters to maximize the chances of finding businesses
    url += "&type=establishment&maxprice=4&rankby=prominence"

    // Request maximum results per page (20 is the API limit)
    url += "&radius=50000"

    // Add timestamp to prevent caching
    url += `&_nocache=${timestamp}`

    console.log("Fetching from Google Places API:", url.replace(key, "API_KEY_HIDDEN"))

    // Make request to Google Places API with proper headers and no-cache
    const response = await fetch(url, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
      cache: "no-store",
    })

    console.log("Google API response status:", response.status, response.statusText)

    const responseText = await response.text()
    console.log("Google API raw response (first 500 chars):", responseText.substring(0, 500) + "...")

    if (!response.ok) {
      console.error("Google API error response:", responseText)
      return NextResponse.json(
        { error: `Google API returned ${response.status}: ${responseText}` },
        { status: response.status },
      )
    }

    // Parse the response text to JSON
    let data
    try {
      data = JSON.parse(responseText)

      // Log the entire response structure for debugging
      console.log("Google API response structure:", {
        status: data.status,
        hasResults: !!data.results,
        resultCount: data.results?.length || 0,
        hasNextPage: !!data.next_page_token,
        errorMessage: data.error_message,
        firstResult: data.results && data.results.length > 0 ? Object.keys(data.results[0]).join(", ") : "No results",
      })
    } catch (parseError) {
      console.error("Error parsing Google API response:", parseError)
      return NextResponse.json(
        { error: "Failed to parse Google API response", details: responseText.substring(0, 1000) },
        { status: 500 },
      )
    }

    // Check for API errors but don't filter out valid responses
    if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
      console.error("Google API error:", data.status, data.error_message || "No error message")
      return NextResponse.json(
        {
          error: `Google API error: ${data.status} - ${data.error_message || "Unknown error"}`,
          details: data,
        },
        { status: 500 },
      )
    }

    // Return the data even if there are no results
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching from Google Places API:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "An unknown error occurred",
        details: error instanceof Error ? error.stack : "No stack trace available",
      },
      { status: 500 },
    )
  }
}
