import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const pagetoken = searchParams.get("pagetoken")
  const key = searchParams.get("key")
  const timestamp = searchParams.get("_t") || Date.now().toString()

  if (!key) {
    return NextResponse.json({ error: "API key is required" }, { status: 400 })
  }

  if (!pagetoken) {
    return NextResponse.json({ error: "Page token is required" }, { status: 400 })
  }

  try {
    // Build the URL for the Google Places API with page token
    const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?pagetoken=${encodeURIComponent(pagetoken)}&key=${encodeURIComponent(key)}&_nocache=${timestamp}`

    console.log("Fetching next page with token")

    // Make request to Google Places API
    const response = await fetch(url, {
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Google API returned ${response.status}: ${errorText}`)
    }

    const data = await response.json()

    // Check for API errors
    if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
      return NextResponse.json(
        {
          error: `Google API error: ${data.status} - ${data.error_message || "Unknown error"}`,
          details: data,
        },
        { status: 500 },
      )
    }

    return NextResponse.json(data)
  } catch (error) {
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "An unknown error occurred",
      },
      { status: 500 },
    )
  }
}
